import random

def pkn():
    computer_choice = random.randint(1,3)
    if computer_choice == 1:
        computer_choice_kamien()
    elif computer_choice == 2:
        computer_choice_papier()
    else:
        computer_chice_nożyce()

def computer_choice_kamien():
    user_choice = input("Wybierz figurę: 1 for kamien, 2 for paper, 3 for nożyce: ")
    if user_choice == "1":
        print ("kamien")
        try_again()
    if user_choice == "2":
        print ("kamien")
        try_again()
    if user_choice == "3":
        print ("kame")
        try_again()
    else:
        print ("try again")
        computer_choice_kamien()
        
def computer_choice_papier():
    user_choice = input("Wybierz figurę: 1 for kamien, 2 for paper, 3 for nożyce: ")
    if user_choice == "1":
        print ("papier")
        try_again()
    if user_choice == "2":
        print ("papier")
        try_again()
    if user_choice == "3":
        print ("papier")
        try_again()
    else:
        print ("try again")
        computer_choice_papier()

def computer_choice_nożyce():
    user_choice = input("Wybierz figurę: 1 for kamien, 2 for paper, 3 for nożyce: ")
    if user_choice == "1":
        print ("nozyce")
        try_again()
    if user_choice == "2":
        print ("nozyce")
        try_again()
    if user_choice == "3":
        print ("nozyce")
        try_again()
    else:
        print ("try again")
        computer_choice_nożyce()



def try_again():
    choice = input("play again? y/n ")
    if choice == "y" or choice == "yes" or choice == "Y":
        pkn()
    elif choice == "n":
        print ("thanks for play")
        quit()
    else:
        print ("try again")
        try_again()
pkn()
        
    

        




        
